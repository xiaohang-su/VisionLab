@echo off
cd /d "%~dp0"
start VisionLab.exe
